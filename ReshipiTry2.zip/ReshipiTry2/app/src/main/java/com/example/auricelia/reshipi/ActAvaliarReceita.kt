package com.example.auricelia.reshipi

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class ActAvaliarReceita : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.act_avaliar_receita)


    }
}
