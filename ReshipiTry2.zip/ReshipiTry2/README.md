# ReshipiTry2
Repositorio do aplicativo reshipe, criado para a disciplina de Desenvolvimento De Aplicativos Moveis.
UFRPE - Ciencia da Computacao 
